//
//  ViewController.swift
//  Susca16
//
//  Created by DANIELE VENTURIN on 21/11/2019.
//  Copyright © 2019 DANIELE VENTURIN. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var btn1: UIButton!
    @IBOutlet weak var btn2: UIButton!
    @IBOutlet weak var btn3: UIButton!
    @IBOutlet weak var btn4: UIButton!
    @IBOutlet weak var btn5: UIButton!
    @IBOutlet weak var btn6: UIButton!
    @IBOutlet weak var btn7: UIButton!
    @IBOutlet weak var btn8: UIButton!
    @IBOutlet weak var btn9: UIButton!
    @IBOutlet weak var btn10: UIButton!
    @IBOutlet weak var btn11: UIButton!
    @IBOutlet weak var btn12: UIButton!
    @IBOutlet weak var btn13: UIButton!
    @IBOutlet weak var btn14: UIButton!
    @IBOutlet weak var btn15: UIButton!
    @IBOutlet weak var btn0: UIButton!
    @IBOutlet weak var btnstart: UIButton!
    @IBOutlet weak var btnreset: UIButton!
    @IBOutlet weak var btnrisolvi: UIButton!
    @IBOutlet weak var lbl_mosse: UILabel!
    @IBOutlet weak var lbl_vittoria: UILabel!
    
    var matrix: [[Int]] = [
        [1, 2, 3, 4],
        [5, 6, 7, 8],
        [9, 10, 11, 12],
        [13, 14, 15, 0]
    ]

    var bottoni: [[UIButton]]?
    
    var ponte = 0;
    var x = 3;
    var y = 3;
    var mosse = 0;
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        bottoni = [[btn1, btn2, btn3, btn4],
        [btn5, btn6, btn7, btn8],
        [btn9, btn10, btn11, btn12],
        [btn13, btn14, btn15, btn0]]
        modifier(t:false)
        btnreset.isUserInteractionEnabled = false
        btnrisolvi.isUserInteractionEnabled = false
    }
    
    func modifier(t: Bool){
        for i in 0 ... 3{
            for j in 0 ... 3{
                bottoni![i][j].isUserInteractionEnabled = t;
            }
        }
    }
    
    func reload() {
        for i in 0 ... 3{
            for j in 0 ... 3{
                bottoni![i][j].setImage(UIImage(named: "\(matrix[i][j])"), for: .normal)
                bottoni![i][j].setTitle(String(matrix[i][j]), for: .normal)
            }
        }
        lbl_mosse.text = String(mosse)
    }

    @IBAction func btn(_ sender: UIButton) {
        check(t:sender.titleLabel!.text!)
    }
    @IBAction func btnstart(_ sender: Any) {
        modifier(t: true)
        resetmatrix();
        btnstart.isUserInteractionEnabled = false
        btnreset.isUserInteractionEnabled = true
        btnrisolvi.isUserInteractionEnabled = true
        var rnd = Int.random(in: 1...4);
        for _ in 0 ... 50{
            switch rnd {
            case 1:
                up();
            case 2:
                dx();
            case 3:
                dw();
            case 4:
                sx();
            default:
                print("ciao");
            }
            rnd = Int.random(in: 1...4);
        }
        reload();
    }
    @IBAction func btnreset(_ sender: Any) {
        resetmatrix()
        matrix[3][3] = 0
        reload()
        modifier(t:false)
        mosse = 0
        lbl_mosse.text = String(mosse)
        lbl_vittoria.text = ""
        btnstart.isUserInteractionEnabled = true;
        btnreset.isUserInteractionEnabled = false
        btnrisolvi.isUserInteractionEnabled = false
    }
    @IBAction func btnrisolvi(_ sender: Any) {
        resetmatrix()
        matrix[3][3] = 0
        reload()
        vittoria()
    }
    func resetmatrix(){
        var c = 1;
        y = 3;
        x = 3;
        for i in 0 ... 3{
            for j in 0 ... 3{
                matrix[i][j] = c;
                c += 1;
            }
        }
    }
    func up(){
        if( y <= 3 && y > 0){
            ponte = matrix[y-1][x];
            matrix[y-1][x] = 0;
            matrix[y][x] = ponte;
            y -= 1;
        }
    }
    func dx(){
        if( x < 3 && x >= 0){
            ponte = matrix[y][x+1];
            matrix[y][x+1] = 0;
            matrix[y][x] = ponte;
            x += 1;
        }
    }
    func dw(){
        if( y < 3 && y >= 0){
            ponte = matrix[y+1][x];
            matrix[y+1][x] = 0;
            matrix[y][x] = ponte;
            y += 1;
        }
    }
    func sx(){
        if( x <= 3 && x > 0){
            ponte = matrix[y][x-1];
            matrix[y][x-1] = 0;
            matrix[y][x] = ponte;
            x -= 1;
        }
    }
    func check(t:String){
        var y1 = 0;
        var x1 = 0;
        for i in 0 ... 3{
            for j in 0 ... 3{
                if(matrix[i][j] == Int(t)){
                    x1 = j;
                    y1 = i;
                }
            }
        }
        if(y1 - 1 >= 0){
            if(matrix[y1 - 1][x1] == 0){
                ponte = matrix[y1 - 1][x1];
                matrix[y1 - 1][x1] = Int(t)!;
                matrix[y1][x1] = 0;
                mosse += 1;
            }
        }
        if(x1 + 1 <= 3){
            if(matrix[y1][x1 + 1] == 0){
                ponte = matrix[y1][x1+1];
                matrix[y1][x1+1] = Int(t)!;
                matrix[y1][x1] = 0;
                mosse += 1;
            }
        }
        if(y1 + 1 <= 3){
            if(matrix[y1 + 1][x1] == 0){
                ponte = matrix[y1 + 1][x1];
                matrix[y1 + 1][x1] = Int(t)!;
                matrix[y1][x1] = 0;
                mosse += 1;
            }
        }
        if(x1 - 1 >= 0){
            if(matrix[y1][x1 - 1] == 0){
                ponte = matrix[y1][x1-1];
                matrix[y1][x1-1] = Int(t)!;
                matrix[y1][x1] = 0;
                mosse += 1;
            }
        }
        reload();
        vittoria();
    }
    func vittoria(){
        if(matrix[0][0] == 1 && matrix[0][1] == 2 && matrix[0][2] == 3 && matrix[0][3] == 4){
            if(matrix[1][0] == 5 && matrix[1][1] == 6 && matrix[1][2] == 7 && matrix[1][3] == 8){
                if(matrix[2][0] == 9 && matrix[2][1] == 10 && matrix[2][2] == 11 && matrix[2][3] == 12){
                    if(matrix[3][0] == 13 && matrix[3][1] == 14 && matrix[3][2] == 15 && matrix[3][3] == 0){
                                                lbl_vittoria.text = "Hai vinto! Premi Reset Per ricominciare"
                        modifier(t:false)
                    }
                }
            }
        }
    }
}

